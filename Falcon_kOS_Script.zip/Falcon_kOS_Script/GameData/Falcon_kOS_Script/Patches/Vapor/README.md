## Vapor Vent
The Plume Party even includes prelaunch smoke and an emitter part (which is near massless and fragile by design). The emitter is as a solid rocket (does not respond to throttle and only drains from itself) but can be shutoff and restarted, and is configured to last just over 5 minutes.

The prelaunch smoke comes in 3 sizes: **Thin, Thick, Ground.**
 
![Vapor Vent](https://raw.githubusercontent.com/JadeOfMaar/PlumeParty/master/GameData/PlumeParty/Vapor/Vapor.jpg)
